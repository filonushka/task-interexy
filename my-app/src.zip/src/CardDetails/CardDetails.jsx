import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { useEffect } from "react";
import { getCharacterById } from "../api/characterApi";

function CardDetails() {
  const { id } = useParams();
  const [characterData, setCharacterData] = useState();

  useEffect(() => {
    getCharacterById().then((res) => setCharacterData(res.results));
  }, []);
  console.log(characterData);

  return <div>{id}</div>;
}

export default CardDetails;
